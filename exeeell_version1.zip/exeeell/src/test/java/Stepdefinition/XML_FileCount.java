package Stepdefinition;

import java.io.File;

import org.junit.Test;

public class XML_FileCount {

	
	public  static int getCount()
	{
		    File directory=new File(System.getProperty("user.dir")+"\\src\\test\\resource\\output_XML");
		    int fileCount=directory.list().length;
		   // System.out.println("File Count:"+fileCount);
		return fileCount;
		  }
		}