package com.cucumber.stepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ChromeStepDefinition {
	public static WebDriver driver;


	@Given("^verify the facebook Homepage user name and  login id are same$")
	public void verify_the_facebook_Homepage_user_name_and_login_id_are_same() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
		System.setProperty("webdriver.chrome.driver", "D:\\maven\\parallelExecution2\\src\\test\\resource\\com\\cucumber\\drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Then("^verify  the facebook Homepage credentials$")
	public void verify_the_facebook_Homepage_credentials() throws Throwable {
		driver.get("https://www.google.com");
	}

	@Then("^click facebook sign out button$")
	public void click_facebook_sign_out_button() throws Throwable {

	}

	

}
