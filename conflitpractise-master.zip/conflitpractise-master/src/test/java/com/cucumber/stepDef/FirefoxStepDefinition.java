package com.cucumber.stepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class FirefoxStepDefinition {

public static WebDriver driver;

@Given("^verify the twitter Homepage user name and  login id are same$")
public void verify_the_twitter_Homepage_user_name_and_login_id_are_same() throws Throwable {
	System.setProperty("webdriver.gecko.driver", "D:\\maven\\parallelExecution2\\src\\test\\resource\\com\\cucumber\\drivers\\geckodriver.exe");
	driver=new FirefoxDriver();
	driver.manage().window().maximize();

}

@Then("^verify  the twitter Homepage credentials$")
public void verify_the_twitter_Homepage_credentials() throws Throwable {
	driver.get("https://www.google.com");
}

@Then("^click twitter sign out button$")
public void click_twitter_sign_out_button() throws Throwable {

}


}
