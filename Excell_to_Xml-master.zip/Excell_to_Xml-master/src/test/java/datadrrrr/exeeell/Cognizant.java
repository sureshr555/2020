package datadrrrr.exeeell;

public class Cognizant {

	public static void main(String[] args) {
	
		
		String name1 = Wallgreen.name1;
		
		
	
		
	}
}
