package parallelExecution2;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features= {"src/test/resource/Chrome.feature","src/test/resource/firefox.feature","src/test/resource/ie.feature"},
		glue= "com.cucumber.stepDef",
		strict=true,
		monochrome=true,
		dryRun=false,
		tags= {"@ie,@firefox,@chrome"}
		
		)


public class Sequential {

}
