package com.cucumber.stepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class IeStepDefinition {

	
public static WebDriver driver;
@Given("^verify the linkden Homepage user name and  login id are same$")
public void verify_the_linkden_Homepage_user_name_and_login_id_are_same() throws Throwable {

	System.setProperty("webdriver.ie.driver","D:\\maven\\parallelExecution2\\src\\test\\resource\\com\\cucumber\\drivers\\IEDriverServer.exe");
	driver=new InternetExplorerDriver();
	driver.manage().window().maximize();

}

@Then("^verify  the linkden Homepage credentials$")
public void verify_the_linkden_Homepage_credentials() throws Throwable {
	driver.get("https://www.google.com");
}

@Then("^click linkden sign out button$")
public void click_linkden_sign_out_button() throws Throwable {

}

}
