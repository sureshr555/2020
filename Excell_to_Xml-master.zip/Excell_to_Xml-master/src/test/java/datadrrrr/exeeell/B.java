package datadrrrr.exeeell;

public class B extends A{
	@Override
	public void TestRun() {
		// TODO Auto-generated method stub
		super.TestRun();
	}
	public static void main(String[] args) {
		
	A a=new A();
	a.TestRun();

}
}