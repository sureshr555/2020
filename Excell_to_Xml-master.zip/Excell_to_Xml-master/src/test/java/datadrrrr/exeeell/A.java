package datadrrrr.exeeell;

public class A {

	public void TestRun()
	{
		System.out.println("a");
	}
}
