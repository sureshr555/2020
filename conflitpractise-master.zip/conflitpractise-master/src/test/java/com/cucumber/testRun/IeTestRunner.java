package com.cucumber.testRun;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"src/test/resource/ie.feature"},
		glue= {"com.cucumber.stepDef"},
		strict=true,
		dryRun=false,
		monochrome=true,
		tags= {"@ie"}
		
		)


public class IeTestRunner {

}
