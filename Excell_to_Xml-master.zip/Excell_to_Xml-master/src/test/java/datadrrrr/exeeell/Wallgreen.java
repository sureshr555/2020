package datadrrrr.exeeell;

public class Wallgreen {

	
	public static String name1="suresh";
	public static String name2="hasan";
	
	public static String name3="saranya";
	
	public static String name4="rajesh";
	
	public static String name5="suresh";
	
	/*public static void getName()
	{
		System.out.println(name);
	}
	*/
	
}
