
public class Pojo {

	
	
	private String DosageFormCd;
	private String DosageFormType;
	private String DrugDefaultSig;
	private String DrugStrength;
	private String GPI;
	private String NDC;
	private String RouteOfAdminCodedVal;
	private String SingleActiveIngredientInd;
	private String DrugClassType;
	
	
	public String getDosageFormCd() {
		return DosageFormCd;
	}
	public void setDosageFormCd(String dosageFormCd) {
		DosageFormCd = dosageFormCd;
	}
	public String getDosageFormType() {
		return DosageFormType;
	}
	public void setDosageFormType(String dosageFormType) {
		DosageFormType = dosageFormType;
	}
	public String getDrugDefaultSig() {
		return DrugDefaultSig;
	}
	public void setDrugDefaultSig(String drugDefaultSig) {
		DrugDefaultSig = drugDefaultSig;
	}
	public String getDrugStrength() {
		return DrugStrength;
	}
	public void setDrugStrength(String drugStrength) {
		DrugStrength = drugStrength;
	}
	public String getGPI() {
		return GPI;
	}
	public void setGPI(String gPI) {
		GPI = gPI;
	}
	public String getNDC() {
		return NDC;
	}
	public void setNDC(String nDC) {
		NDC = nDC;
	}
	public String getRouteOfAdminCodedVal() {
		return RouteOfAdminCodedVal;
	}
	public void setRouteOfAdminCodedVal(String routeOfAdminCodedVal) {
		RouteOfAdminCodedVal = routeOfAdminCodedVal;
	}
	public String getSingleActiveIngredientInd() {
		return SingleActiveIngredientInd;
	}
	public void setSingleActiveIngredientInd(String singleActiveIngredientInd) {
		SingleActiveIngredientInd = singleActiveIngredientInd;
	}
	public String getDrugClassType() {
		return DrugClassType;
	}
	public void setDrugClassType(String drugClassType) {
		DrugClassType = drugClassType;
	}
	
	
	
   

}	
